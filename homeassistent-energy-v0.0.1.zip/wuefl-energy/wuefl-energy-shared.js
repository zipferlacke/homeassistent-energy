/**
 * wuefl-energy-shared.js
 * Gemeinsame Basis für alle wuefl-Energy-Karten.
 */

export const WUEFL_CSS_IMPORT = '/local/libs/wuefl-libs/css/import.css';
export const WUEFL_CSS_THEME = '/local/wuefl-energy/wuefl-energy.css';

/** Einheitliche Farben – dieselbe Größe hat überall dieselbe Farbe. */
export const COLORS = {
  pv: 'var(--clr-warning-600, #ef9f27)',
  grid_import: 'var(--clr-neutral-600, #5f5e5a)',
  grid_export: 'var(--clr-neutral-400, #b4b2a9)',
  battery_out: 'var(--clr-success-600, #639922)',
  battery_in: 'var(--clr-success-300, #c0dd97)',
  house: 'var(--clr-info-600, #378add)',
  wallbox: 'var(--clr-secondary-600, #7f77dd)',
  heatpump: 'var(--clr-danger-500, #d85a30)',
  price: 'var(--clr-primary-600, #fbaa00)',
};

/** Material Symbols Rounded, aus wuefl-libs/css/fonts. */
export const ICONS = {
  pv: 'solar_power',
  grid_import: 'south_east',
  grid_export: 'north_east',
  battery_out: 'battery_5_bar',
  battery_in: 'battery_charging_full',
  house: 'home',
  wallbox: 'ev_station',
  heatpump: 'heat_pump',
  price: 'euro',
};

export function linkWueflStyles(root, config = {}) {
  for (const href of [config.css_base ?? WUEFL_CSS_IMPORT, config.css_theme ?? WUEFL_CSS_THEME]) {
    if (!href || root.querySelector(`link[href="${href}"]`)) continue;
    const link = document.createElement('link');
    link.rel = 'stylesheet';
    link.href = href;
    root.appendChild(link);
  }
}

export function adoptSheet(root, cssText, cache = {}, key = 'default') {
  if (!cache[key]) {
    cache[key] = new CSSStyleSheet();
    cache[key].replaceSync(cssText);
  }
  root.adoptedStyleSheets = [...(root.adoptedStyleSheets ?? []), cache[key]];
}

/* ------------------------------------------------------------------ *
 * Zustände lesen
 * ------------------------------------------------------------------ */

/** Nimmt einen String, eine Liste oder undefined und liefert immer eine Liste. */
export function asList(value) {
  if (!value) return [];
  return Array.isArray(value) ? value.filter(Boolean) : [value];
}

export function num(hass, entityId, { invert = false } = {}) {
  if (!hass || !entityId) return null;
  const v = Number(hass.states[entityId]?.state);
  return Number.isFinite(v) ? v * (invert ? -1 : 1) : null;
}

function unitOf(hass, entityId) {
  return (hass?.states?.[entityId]?.attributes?.unit_of_measurement ?? '').toLowerCase();
}

/** Leistung in Watt, egal ob der Sensor W, kW oder MW liefert. */
export function power(hass, entityId, opts = {}) {
  const v = num(hass, entityId, opts);
  if (v === null) return null;
  const u = unitOf(hass, entityId);
  return u === 'kw' ? v * 1000 : u === 'mw' ? v * 1e6 : v;
}

/** Energie in kWh, egal ob der Sensor Wh, kWh oder MWh liefert. */
export function energy(hass, entityId, opts = {}) {
  const v = num(hass, entityId, opts);
  if (v === null) return null;
  const u = unitOf(hass, entityId);
  return u === 'wh' ? v / 1000 : u === 'mwh' ? v * 1000 : v;
}

/** Summe über eine Liste von Entitäten. Leere Liste ergibt null. */
export function sum(hass, ids, fn = power, opts = {}) {
  const list = asList(ids);
  if (!list.length) return null;
  let total = 0;
  let any = false;
  for (const id of list) {
    const v = fn(hass, id, opts);
    if (v !== null) {
      total += v;
      any = true;
    }
  }
  return any ? total : null;
}

/** Einzelwerte mit Namen – für Aufschlüsselungen wie PV-Stränge. */
export function breakdown(hass, ids, fn = power, opts = {}) {
  return asList(ids)
    .map((id) => ({
      id,
      name: hass?.states?.[id]?.attributes?.friendly_name ?? id,
      value: fn(hass, id, opts),
    }))
    .filter((e) => e.value !== null);
}

/* ------------------------------------------------------------------ *
 * Formatierung
 * ------------------------------------------------------------------ */

const de = (v, d) =>
  new Intl.NumberFormat('de-DE', { minimumFractionDigits: d, maximumFractionDigits: d }).format(v);

export function fmtPower(watt) {
  if (watt === null || watt === undefined) return '–';
  const a = Math.abs(watt);
  return a >= 1000 ? `${de(watt / 1000, a >= 10000 ? 1 : 2)} kW` : `${de(Math.round(watt), 0)} W`;
}

export function fmtEnergy(kwh) {
  if (kwh === null || kwh === undefined) return '–';
  const a = Math.abs(kwh);
  if (a >= 1000) return `${de(kwh / 1000, 2)} MWh`;
  if (a >= 100) return `${de(kwh, 0)} kWh`;
  if (a >= 10) return `${de(kwh, 1)} kWh`;
  return `${de(kwh, 2)} kWh`;
}

export function fmtPercent(v, d = 0) {
  return v === null || v === undefined ? '–' : `${de(v, d)} %`;
}

export function fmtSigned(kwh) {
  if (kwh === null || kwh === undefined) return '–';
  return `${kwh < 0 ? '−' : '+'} ${fmtEnergy(Math.abs(kwh))}`;
}

export function fmtPrice(ct) {
  return ct === null || ct === undefined ? '–' : `${de(ct, 1)} ct`;
}

export function fmtClock(date) {
  return new Intl.DateTimeFormat('de-DE', { hour: '2-digit', minute: '2-digit' }).format(date);
}

/* ------------------------------------------------------------------ *
 * Strompreis
 * ------------------------------------------------------------------ */

/**
 * Liefert { now, unit, forecast } in ct/kWh.
 * Der Sensor darf einen festen Wert liefern oder eine Liste im Attribut.
 * Fehlt der Sensor, greift der Festpreis aus der Config.
 */
export function priceInfo(hass, config, direction = 'import') {
  const entity = direction === 'import' ? config.price_entity : config.price_export_entity;
  const fixed = direction === 'import' ? config.price_import_fixed : config.price_export_fixed;
  const st = entity ? hass?.states?.[entity] : null;

  if (!st) return { now: fixed ?? null, unit: 'ct/kWh', forecast: [], fixed: true };

  let now = Number(st.state);
  const unit = st.attributes.unit_of_measurement ?? 'ct/kWh';
  // €/kWh-Sensoren auf ct umrechnen, damit die Achse lesbar bleibt
  const toCt = /€|eur/i.test(unit) && !/ct|cent/i.test(unit) ? 100 : 1;
  if (Number.isFinite(now)) now *= toCt;
  else now = fixed ?? null;

  const attr = config.price_forecast_attribute ?? 'prices';
  const raw = st.attributes[attr] ?? st.attributes.forecast ?? st.attributes.data ?? [];
  const forecast = (Array.isArray(raw) ? raw : [])
    .map((e) => {
      const t = e.start_time ?? e.startsAt ?? e.start ?? e.time ?? e.datetime;
      const v = e.price ?? e.total ?? e.value ?? e.marketprice;
      return t && Number.isFinite(Number(v))
        ? { time: new Date(t), value: Number(v) * toCt }
        : null;
    })
    .filter(Boolean);

  return { now, unit: 'ct/kWh', forecast, fixed: false };
}

/* ------------------------------------------------------------------ *
 * Diverses
 * ------------------------------------------------------------------ */

export function fireEvent(node, type, detail = {}) {
  node.dispatchEvent(new CustomEvent(type, { detail, bubbles: true, composed: true }));
}

export function moreInfo(node, entityId) {
  if (entityId) fireEvent(node, 'hass-more-info', { entityId });
}

export function registerCard(entry) {
  window.customCards = window.customCards || [];
  if (!window.customCards.some((c) => c.type === entry.type)) {
    window.customCards.push({ preview: true, ...entry });
  }
}

export const WEATHER_ICONS = {
  'clear-night': 'bedtime',
  cloudy: 'cloud',
  exceptional: 'priority_high',
  fog: 'foggy',
  hail: 'weather_hail',
  lightning: 'thunderstorm',
  'lightning-rainy': 'thunderstorm',
  partlycloudy: 'partly_cloudy_day',
  pouring: 'rainy_heavy',
  rainy: 'rainy',
  snowy: 'weather_snowy',
  'snowy-rainy': 'weather_mix',
  sunny: 'clear_day',
  windy: 'air',
  'windy-variant': 'air',
};

export const weatherIcon = (c) => WEATHER_ICONS[c] ?? 'thermostat';
export const WEEKDAYS = ['So', 'Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa'];

/** Kleines Flächendiagramm für Preis- und Prognosestreifen. */
export function sparkline(points, color, { width = 300, height = 78, pad = 5 } = {}) {
  if (!points.length) return '';
  const max = Math.max(...points);
  const min = Math.min(0, ...points);
  const span = max - min || 1;
  const x = (i) => pad + (points.length < 2 ? width / 2 : (i / (points.length - 1)) * (width - 2 * pad));
  const y = (v) => height - pad - ((v - min) / span) * (height - 2 * pad);
  const line = points.map((v, i) => `${i ? 'L' : 'M'}${x(i).toFixed(1)} ${y(v).toFixed(1)}`).join(' ');
  const id = `sg${Math.random().toString(36).slice(2, 8)}`;
  return `<svg viewBox="0 0 ${width} ${height}" preserveAspectRatio="none" class="spark">
    <defs><linearGradient id="${id}" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="${color}" stop-opacity="0.45"/>
      <stop offset="1" stop-color="${color}" stop-opacity="0"/>
    </linearGradient></defs>
    <path d="${line} L${x(points.length - 1).toFixed(1)} ${height - pad} L${pad} ${height - pad} Z" fill="url(#${id})"/>
    <path d="${line}" fill="none" stroke="${color}" stroke-width="2.5" stroke-linejoin="round" vector-effect="non-scaling-stroke"/>
  </svg>`;
}

/* ------------------------------------------------------------------ *
 * Editor-Basis: ha-form mit deutschen Beschriftungen
 * ------------------------------------------------------------------ */

export class WueflFormEditor extends HTMLElement {
  _config = {};
  _hass = null;
  _form = null;
  schema = [];
  labels = {};

  setConfig(config) {
    this._config = config;
    this._sync();
  }

  set hass(hass) {
    this._hass = hass;
    this._sync();
  }

  connectedCallback() {
    if (this._form) return;
    this._form = document.createElement('ha-form');
    this._form.computeLabel = (s) => this.labels[s.name] ?? s.title ?? s.name;
    this._form.addEventListener('value-changed', (ev) => {
      this.dispatchEvent(
        new CustomEvent('config-changed', {
          detail: { config: ev.detail.value },
          bubbles: true,
          composed: true,
        }),
      );
    });
    this.appendChild(this._form);
    this._sync();
  }

  _sync() {
    if (!this._form) return;
    this._form.hass = this._hass;
    this._form.data = this._config;
    this._form.schema = this.schema;
  }
}

/** Kurzschreibweisen für Selektoren im Editor. */
export const sel = {
  text: () => ({ text: {} }),
  bool: () => ({ boolean: {} }),
  entity: (domain = 'sensor') => ({ entity: { filter: { domain } } }),
  entities: (domain = 'sensor') => ({ entity: { filter: { domain }, multiple: true } }),
  any: () => ({ entity: {} }),
  pick: (domains) => ({ entity: { filter: domains.map((d) => ({ domain: d })) } }),
  number: (min, max, step = 1) => ({ number: { min, max, step, mode: 'box' } }),
};

/* ------------------------------------------------------------------ *
 * Zentrale Zuordnung aus der Integration
 * ------------------------------------------------------------------ */

let centralPromise = null;
let centralSubscribed = false;

/**
 * Holt die auf der Seite "wuefl Energie" gepflegte Zuordnung.
 * Fehlt die Integration, kommt ein leeres Objekt zurück und die Karten
 * arbeiten allein mit ihrer eigenen Konfiguration weiter.
 */
export async function centralConfig(hass, section) {
  if (!hass) return {};

  if (!centralPromise) {
    centralPromise = hass.callWS({ type: 'wuefl_energy/get' }).catch(() => ({}));
  }
  const all = (await centralPromise) ?? {};

  if (!centralSubscribed && hass.connection) {
    centralSubscribed = true;
    hass.connection
      .subscribeEvents(() => {
        centralPromise = null;
        window.dispatchEvent(new CustomEvent('wuefl-energy-config-changed'));
      }, 'wuefl_energy_updated')
      .catch(() => {});
  }

  return (section ? all[section] : all) ?? {};
}

/**
 * Mischt zentrale Zuordnung und Kartenkonfiguration.
 * Was in der Karte steht, gewinnt – sonst wäre die Karte nicht mehr
 * einzeln anpassbar.
 */
export function mergeConfig(central, own) {
  const out = { ...(central ?? {}) };
  for (const [k, v] of Object.entries(own ?? {})) {
    if (v !== undefined && v !== null && v !== '') out[k] = v;
  }
  return out;
}

/** Geldwert in Euro, mit Vorzeichen. */
export function fmtEuro(value, { signed = true } = {}) {
  if (value === null || value === undefined) return '–';
  const s = new Intl.NumberFormat('de-DE', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(Math.abs(value));
  if (!signed) return `${s} €`;
  return `${value < 0 ? '−' : '+'} ${s} €`;
}

/** Restdauer als "2 h 10 min". */
export function fmtDuration(hours) {
  const total = Math.round(hours * 60);
  if (total < 1) return 'gleich';
  const h = Math.floor(total / 60);
  const m = total % 60;
  return h ? `${h} h ${m} min` : `${m} min`;
}
