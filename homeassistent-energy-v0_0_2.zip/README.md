# wuefl Energie für Home Assistant

Drei Karten (Live-Energiefluss, Energiebilanz, Wallbox) plus eine kleine
Integration, die alle Entitäten an einer zentralen Stelle zuordnet.

Keine externen Abhängigkeiten: keine Bibliothek, kein Font, kein Build-Schritt.
Farben und Maße kommen aus dem aktiven Home-Assistant-Theme, Icons aus dem
mitgelieferten Material-Design-Icons-Satz.

## Installation

1. Ordner `custom_components/wuefl_energy` nach `config/custom_components/`
   kopieren.
2. Ordner `www/wuefl-energy` nach `config/www/` kopieren.
3. In `configuration.yaml` ergänzen:

   ```yaml
   wuefl_energy:
   ```

4. Home Assistant neu starten.
5. Einstellungen → Dashboards → Ressourcen, drei Einträge als **JavaScript-Modul**:

   ```
   /local/wuefl-energy/wuefl-energy-live-card.js
   /local/wuefl-energy/wuefl-energy-history-card.js
   /local/wuefl-energy/wuefl-wallbox-card.js
   ```

   `wuefl-energy-shared.js` wird nicht eingetragen — die drei Karten
   importieren sie selbst.

6. Optional: `wuefl_wallbox.yaml` nach `config/packages/` legen, wenn die
   Helfer und die Ladeautomatik mit sollen.
7. Dashboard anlegen und `energie-dashboard.yaml` im Raw-Editor einfügen.

Danach steht in der Seitenleiste **wuefl Energie**. Dort werden die Sensoren
einmal zugeordnet und gelten für alle Karten. Wer eine einzelne Karte
abweichend belegen will, trägt den Wert im Karteneditor ein — der schlägt
die zentrale Zuordnung.

## Eigene Farben

Alles läuft über CSS-Variablen. Für die Energiefarben nutzen die Karten die,
die Home Assistant im eingebauten Energie-Dashboard setzt — sie passen also
ohne Zutun zusammen. Überschreiben geht im Theme:

```yaml
mein-theme:
  # von Home Assistant vorgegeben
  energy-solar-color: "#ff9800"
  energy-grid-consumption-color: "#488fc2"
  energy-grid-return-color: "#8353d1"
  energy-battery-in-color: "#f6c34c"
  energy-battery-out-color: "#4db0a2"
  # nur in diesen Karten
  wuefl-house-color: "#488fc2"
  wuefl-wallbox-color: "#7f77dd"
  wuefl-heatpump-color: "#d85a30"
  wuefl-price-color: "#fbaa00"
```

Maße und Schriftgrößen hängen an `--w-radius`, `--w-pad`, `--w-input-h` und
`--w-fs-sm|md|lg`. Sie stehen gesammelt in `TOKENS_CSS` in
`wuefl-energy-shared.js`.

## Aufbau

| Datei | Zweck |
|---|---|
| `wuefl-energy-shared.js` | Tokens, Grundgerüst-CSS, Farben, Icons, Formatierung, Editor-Basis |
| `wuefl-energy-live-card.js` | Energiefluss-Grafik mit laufenden Kabeln |
| `wuefl-energy-history-card.js` | Bilanz über Tag/Woche/Monat/Jahr |
| `wuefl-wallbox-card.js` | Lademodus, Ladeziel, Zeitprognose je Fahrzeug |
| `energieflow.svg` | Die Grafik der Live-Karte |
| `custom_components/wuefl_energy/` | Zentrale Zuordnung, Seite in der Seitenleiste |

## Hinweise

* Die Live-Karte holt `energieflow.svg` per `fetch`. Ein abweichender Pfad
  lässt sich im Karteneditor unter *Pfad zur Grafik* setzen.
* Die Energie-Ansicht liest Langzeitstatistiken. Die Sensoren brauchen dafür
  `state_class: total_increasing` und müssen vom Recorder erfasst werden.
* Farben in SVG werden immer über `style="fill: …"` gesetzt, nie über
  `fill="…"`: Browser werten `var()` in Präsentationsattributen nicht aus.
